// import 'package:flutter/material.dart';
// import 'theme/app_theme.dart';
// import 'routes/app_routes.dart';

// void main() {
//   runApp(const HealthTrackerApp());
// }

// class HealthTrackerApp extends StatelessWidget {
//   const HealthTrackerApp({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       title: 'MediCare+',
//       debugShowCheckedModeBanner: false,
//       theme: AppTheme.lightTheme(),
//       initialRoute: AppRoutes.home,
//       routes: AppRoutes.routes,
//     );
//   }
// }

import 'package:flutter/material.dart';

import 'screens/auth/home_page.dart';
import 'screens/auth/signin_screen.dart';
import 'screens/auth/create_acct.dart';
import 'screens/auth/health_profile.dart';
import 'screens/auth/security_setup_page.dart';
import 'screens/dashboard/dashboard_page.dart';

void main() {
  runApp(const MediCareApp());
}

class MediCareApp extends StatelessWidget {
  const MediCareApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'MediCare+',
      theme: ThemeData(useMaterial3: true),
      initialRoute: '/',
      routes: {
        '/': (context) => const HomePage(),
        '/signin': (context) => const SignInPage(),
        '/create-account': (context) => const CreateAccountPage(),
        '/health-profile': (context) => const HealthProfilePage(),
        '/security-setup': (context) => const SecuritySetupPage(),
        '/dashboard': (context) => const DashboardPage(),
      },
    );
  }
}
