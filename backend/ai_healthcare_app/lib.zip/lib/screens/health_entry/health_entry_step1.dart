import 'package:flutter/material.dart';
import 'health_entry_step2.dart';

class HealthEntryStep1 extends StatefulWidget {
  const HealthEntryStep1({super.key});

  @override
  State<HealthEntryStep1> createState() => _HealthEntryStep1State();
}

class _HealthEntryStep1State extends State<HealthEntryStep1> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _heartRateController = TextEditingController();
  final TextEditingController _systolicController = TextEditingController();
  final TextEditingController _diastolicController = TextEditingController();

  @override
  void dispose() {
    _heartRateController.dispose();
    _systolicController.dispose();
    _diastolicController.dispose();
    super.dispose();
  }

  void _continueToNextStep() {
    if (_formKey.currentState!.validate()) {
      // Here you would typically save the data
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const HealthEntryStep2()),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: const Text(
          'Health Data Entry',
          style: TextStyle(
            color: Colors.white,
            fontSize: 20,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFF0EA5E9), // Light blue
              Color(0xFF0284C7), // Medium blue
              Color(0xFF0369A1), // Darker blue
            ],
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 20),

                // Subtitle
                const Text(
                  'Enter your current health metrics',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.w400,
                  ),
                ),

                const SizedBox(height: 30),

                // Step Indicator
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    _buildStepIndicator(isActive: true), // Step 1
                    _buildStepConnector(),
                    _buildStepIndicator(isActive: false), // Step 2
                    _buildStepConnector(),
                    _buildStepIndicator(isActive: false), // Step 3
                  ],
                ),

                const SizedBox(height: 40),

                // Vital Signs Card
                Expanded(
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(24),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(24),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withValues(alpha: 0.1),
                          blurRadius: 20,
                          offset: const Offset(0, 10),
                        ),
                      ],
                    ),
                    child: Form(
                      key: _formKey,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'Vital Signs',
                            style: TextStyle(
                              fontSize: 24,
                              fontWeight: FontWeight.bold,
                              color: Color(0xFF1F2937),
                            ),
                          ),

                          const SizedBox(height: 8),

                          const Text(
                            'Please enter your current vital measurements',
                            style: TextStyle(fontSize: 14, color: Colors.grey),
                          ),

                          const SizedBox(height: 32),

                          // Heart Rate Field
                          _buildInputField(
                            controller: _heartRateController,
                            label: 'Heart Rate',
                            unit: 'bpm',
                            icon: Icons.favorite,
                            color: Colors.red,
                            validator: (value) {
                              if (value == null || value.isEmpty) {
                                return 'Please enter heart rate';
                              }
                              final rate = int.tryParse(value);
                              if (rate == null || rate < 40 || rate > 200) {
                                return 'Enter valid heart rate (40-200 bpm)';
                              }
                              return null;
                            },
                          ),

                          const SizedBox(height: 20),

                          // Systolic BP Field
                          _buildInputField(
                            controller: _systolicController,
                            label: 'Systolic Blood Pressure',
                            unit: 'mmHg',
                            icon: Icons.monitor_heart,
                            color: Colors.blue,
                            validator: (value) {
                              if (value == null || value.isEmpty) {
                                return 'Please enter systolic BP';
                              }
                              final bp = int.tryParse(value);
                              if (bp == null || bp < 80 || bp > 250) {
                                return 'Enter valid systolic BP (80-250 mmHg)';
                              }
                              return null;
                            },
                          ),

                          const SizedBox(height: 20),

                          // Diastolic BP Field
                          _buildInputField(
                            controller: _diastolicController,
                            label: 'Diastolic Blood Pressure',
                            unit: 'mmHg',
                            icon: Icons.monitor_heart,
                            color: Colors.blue,
                            validator: (value) {
                              if (value == null || value.isEmpty) {
                                return 'Please enter diastolic BP';
                              }
                              final bp = int.tryParse(value);
                              if (bp == null || bp < 50 || bp > 150) {
                                return 'Enter valid diastolic BP (50-150 mmHg)';
                              }
                              return null;
                            },
                          ),

                          const Spacer(),

                          // Continue Button
                          SizedBox(
                            width: double.infinity,
                            height: 56,
                            child: ElevatedButton(
                              onPressed: _continueToNextStep,
                              style: ElevatedButton.styleFrom(
                                backgroundColor: const Color(0xFF10B981),
                                foregroundColor: Colors.white,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(16),
                                ),
                                elevation: 0,
                                shadowColor: Colors.transparent,
                              ),
                              child: const Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text(
                                    'Continue',
                                    style: TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                  SizedBox(width: 8),
                                  Icon(Icons.arrow_forward, size: 20),
                                ],
                              ),
                            ),
                          ),

                          const SizedBox(height: 16),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildStepIndicator({required bool isActive}) {
    return Container(
      width: 12,
      height: 12,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: isActive ? Colors.white : Colors.white.withValues(alpha: 0.3),
        border: Border.all(color: Colors.white, width: 2),
      ),
    );
  }

  Widget _buildStepConnector() {
    return Container(
      width: 40,
      height: 2,
      color: Colors.white.withValues(alpha: 0.3),
    );
  }

  Widget _buildInputField({
    required TextEditingController controller,
    required String label,
    required String unit,
    required IconData icon,
    required Color color,
    required String? Function(String?) validator,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w600,
            color: Color(0xFF374151),
          ),
        ),
        const SizedBox(height: 8),
        TextFormField(
          controller: controller,
          keyboardType: TextInputType.number,
          style: const TextStyle(fontSize: 16, color: Color(0xFF1F2937)),
          decoration: InputDecoration(
            prefixIcon: Container(
              padding: const EdgeInsets.all(12),
              child: Icon(icon, color: color, size: 24),
            ),
            suffixText: unit,
            suffixStyle: TextStyle(
              color: Colors.grey[600],
              fontSize: 16,
              fontWeight: FontWeight.w500,
            ),
            filled: true,
            fillColor: const Color(0xFFF9FAFB),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide.none,
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(color: Colors.grey[300]!, width: 1),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(color: color, width: 2),
            ),
            errorBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: const BorderSide(color: Colors.red, width: 1),
            ),
            focusedErrorBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: const BorderSide(color: Colors.red, width: 2),
            ),
            contentPadding: const EdgeInsets.symmetric(
              horizontal: 16,
              vertical: 16,
            ),
          ),
          validator: validator,
        ),
      ],
    );
  }
}
