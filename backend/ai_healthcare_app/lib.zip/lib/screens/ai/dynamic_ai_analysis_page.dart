import 'package:flutter/material.dart';
import '../../services/api_service.dart';

class DynamicAIAnalysisPage extends StatefulWidget {
  const DynamicAIAnalysisPage({super.key});

  @override
  State<DynamicAIAnalysisPage> createState() => _DynamicAIAnalysisPageState();
}

class _DynamicAIAnalysisPageState extends State<DynamicAIAnalysisPage> {
  final _heartRateCtrl = TextEditingController();
  final _bpCtrl = TextEditingController();
  final _sugarCtrl = TextEditingController();
  final _bmiCtrl = TextEditingController();

  String result = "";
  Color resultColor = Colors.grey;
  String selectedModel = 'heart';
  Map<String, double> _suggested = {};

  Future<void> analyzeData() async {
    final double hr = double.tryParse(_heartRateCtrl.text) ?? 0;
    final double bp = double.tryParse(_bpCtrl.text) ?? 0;
    final double sugar = double.tryParse(_sugarCtrl.text) ?? 0;
    final double bmi = double.tryParse(_bmiCtrl.text) ?? 0;

    // Prepare features vector (simple example). Adjust ordering per model expectation.
    final features = [hr, bp, sugar, bmi];

    setState(() {
      result = 'Analyzing...';
      resultColor = Colors.blueGrey;
      _suggested = {};
    });

    try {
      Map<String, dynamic> resp;
      if (selectedModel == 'heart') {
        resp = await ApiService.predictHeart(features);
      } else if (selectedModel == 'diabetes') {
        resp = await ApiService.predictDiabetes(features);
      } else if (selectedModel == 'kidney') {
        resp = await ApiService.predictKidney(features);
      } else {
        resp = await ApiService.predictThyroid(features);
      }

      final String modelName = resp['disease'] ?? selectedModel;
      final String out = resp['result'] ?? resp['message'] ?? 'Unknown';

      // Build human-friendly message and suggested adjustments
      String message = 'Model: $modelName\nResult: $out';
      Map<String, double> suggested = {};
      if (out.toLowerCase().contains('high')) {
        message +=
            '\n\nRecommendations:\n- Consult your physician.\n- Re-check vitals in 24-48 hours.';
        // Simple suggested adjustments to demonstrate "data should change"
        if (bp > 120) suggested['bp'] = (bp * 0.9).roundToDouble();
        if (sugar > 120) suggested['sugar'] = (sugar * 0.85).roundToDouble();
        if (bmi > 24.9) suggested['bmi'] = (bmi * 0.95);
      } else {
        message += '\n\nAll parameters look good. Maintain healthy habits.';
      }

      setState(() {
        result = message;
        resultColor = out.toLowerCase().contains('high')
            ? Colors.orange
            : Colors.green;
        _suggested = suggested;
      });
    } catch (e) {
      setState(() {
        result = 'Error analyzing data: $e';
        resultColor = Colors.red;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF020617),
      appBar: AppBar(
        title: const Text("AI Health Analysis"),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              "Enter Your Health Data",
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 20),

            _inputField("Heart Rate (bpm)", _heartRateCtrl),
            _inputField("Blood Pressure (systolic)", _bpCtrl),
            _inputField("Blood Sugar (mg/dL)", _sugarCtrl),
            _inputField("BMI", _bmiCtrl),

            const SizedBox(height: 24),

            SizedBox(
              width: double.infinity,
              height: 50,
              child: ElevatedButton(
                onPressed: analyzeData,
                child: const Text("Analyze with AI"),
              ),
            ),

            const SizedBox(height: 32),

            if (result.isNotEmpty)
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: resultColor.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: resultColor, width: 1),
                ),
                child: Text(
                  result,
                  style: const TextStyle(fontSize: 14, height: 1.6),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _inputField(String label, TextEditingController controller) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: TextField(
        controller: controller,
        keyboardType: TextInputType.number,
        decoration: InputDecoration(
          labelText: label,
          border: const OutlineInputBorder(),
        ),
      ),
    );
  }
}
