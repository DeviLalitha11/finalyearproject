import 'package:flutter/material.dart';
import '../screens/auth/home_page.dart';
import '../screens/auth/signin_screen.dart';
import '../screens/dashboard/dashboard_page.dart';
import '../screens/ai/dynamic_ai_analysis_page.dart';
import '../screens/health_entry/health_entry_step1.dart';
import '../screens/profile/profile_page.dart';
import '../screens/records/medical_records_page.dart';
import '../screens/settings/settings_screen.dart';

class AppRoutes {
  static const String home = '/';
  static const String signin = '/signin';
  static const String dashboard = '/dashboard';
  static const String aiAnalysis = '/ai-analysis';
  static const String healthEntry = '/health-entry';
  static const String profile = '/profile';
  static const String records = '/records';
  static const String settings = '/settings';

  static Map<String, WidgetBuilder> get routes => {
    home: (context) => const HomePage(),
    signin: (context) => const SignInPage(),
    dashboard: (context) => const DashboardPage(),
    aiAnalysis: (context) => const DynamicAIAnalysisPage(),
    healthEntry: (context) => const HealthEntryStep1(),
    profile: (context) => const ProfilePage(),
    records: (context) => const MedicalRecordsPage(),
    settings: (context) => const SettingsScreen(),
  };
}
